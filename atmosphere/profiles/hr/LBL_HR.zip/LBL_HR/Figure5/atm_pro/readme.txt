surface_temperature number_of_level
Height (km)     Pressure (hPa)     Temperature (K)     Water vapor mixing ratio (kg/kg)     Ozone mixing ratio (kg/kg)
.
.
.
.
.
.
Height (km)     Pressure (hPa)     Temperature (K)     Water vapor mixing ratio (kg/kg)     Ozone mixing ratio (kg/kg)


